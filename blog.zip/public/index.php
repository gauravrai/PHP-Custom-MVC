<?php
/*

	Landing file, browser will point this file

*/
require_once('../app/init.php');